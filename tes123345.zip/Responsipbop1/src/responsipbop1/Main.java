/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package responsipbop1;

import java.util.Scanner;

/**
 *
 * @author LABKOMDS
 */
public class Main {

    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);

        BRI bri1 = new BRI();
        BNI bni1 = new BNI();

        String BRI = null, BNI = null;
//        System.out.println("Masukkan Nama Bank [BRI/BNI]: ");
//        String namabank = scn.nextLine();

        while (true) {
            System.out.println("");
            System.out.println("===========================");
            System.out.println("            ATM2           ");
            System.out.println("===========================");
            System.out.println("1. BRI                     ");
            System.out.println("2. BNI                     ");
            System.out.println("3. KELUAR                  ");
            System.out.println("===========================");
            System.out.println("");

            System.out.println("Masukkan pilihan : ");
            int pilih1 = scn.nextInt();

            System.out.println();

            switch (pilih1) {
                case 1:
                    while (true) {
                        System.out.println("");
                        System.out.println("===========================");
                        System.out.println("            ATM            ");
                        System.out.println("===========================");
                        System.out.println("1. LIHAT SALDO             ");
                        System.out.println("2. TARIK TUNAI             ");
                        System.out.println("3. SETOR TUNAI             ");
                        System.out.println("4. KELUAR                  ");
                        System.out.println("===========================");
                        System.out.println("");

                        System.out.println("Masukkan pilihan : ");
                        int pilih2 = scn.nextInt();

                        System.out.println();

                        switch (pilih2) {
                            case 1:
                                    bri1.lihat_saldo(300000);
                                break;
                            case 2:
                                    bri1.tarik_tunai(100000);
                                break;
                            case 3:
                                    bri1.setor_tunai(200000);
                                break;
                            default:
                                System.out.println("===========================");
                                System.out.println("===     TERIMA KASIH    ===");
                                System.out.println("===========================");
                                System.exit(0);
                        }
                    }
                case 2:
                    while (true) {
                        System.out.println("");
                        System.out.println("===========================");
                        System.out.println("            ATM            ");
                        System.out.println("===========================");
                        System.out.println("1. LIHAT SALDO             ");
                        System.out.println("2. TARIK TUNAI             ");
                        System.out.println("3. SETOR TUNAI             ");
                        System.out.println("4. KELUAR                  ");
                        System.out.println("===========================");
                        System.out.println("");

                        System.out.println("Masukkan pilihan : ");
                        int pilih3 = scn.nextInt();

                        System.out.println();

                        switch (pilih3) {
                            case 1:
                                    bni1.lihat_saldo(500000);
                                break;
                            case 2:
                                    bni1.tarik_tunai(200000);
                                break;
                            case 3:
                                    bni1.setor_tunai(400000);
                                break;
                            default:
                                System.out.println("===========================");
                                System.out.println("===     TERIMA KASIH    ===");
                                System.out.println("===========================");
                                System.exit(0);
                        }
                    }
                default:
                    System.out.println("===========================");
                    System.out.println("===     TERIMA KASIH    ===");
                    System.out.println("===========================");
                    System.exit(0);
            }
        }
    }
}
