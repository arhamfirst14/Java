package responsipbop1;

import java.util.Scanner;

class ATM {
    protected int saldo, tarik, setor;
    Scanner scn= new Scanner(System.in);
    
    public void setSaldo(int saldo){this.saldo=saldo;}
    public void setTarik(int tarik){this.saldo=tarik;}
    public void setSetor(int setor){this.saldo=setor;}
    public int getSaldo(){return this.saldo;}
    public int getTarik(){return this.tarik;}
    public int getSetor(){return this.setor;}
    
    protected void input(int saldo, int tarik, int setor){
        setSaldo(saldo);
        setTarik(tarik);
        setSetor(setor);
    }
    
    public void lihat_saldo(int sld){
        this.saldo=sld;
            System.out.println("===     LIHAT SALDO     ===");
            System.out.println("Saldo Anda          : " + this.saldo);
            System.out.println("");
     }
     
     public void tarik_tunai(int trk){
         if(this.saldo <= trk){
            System.out.println("===     TARIK TUNAI     ===");
            System.out.println("Saldo Anda Tidak Mencukupi");
            System.out.println("");
         }else this.saldo=this.saldo-trk;{
            System.out.println("===     TARIK TUNAI     ===");
            System.out.println("Saldo Yang Ditarik  : "+trk);
            System.out.println("Sisa Saldo Saat Ini : " +this.saldo);
            System.out.println("");
        }
    }
     
     public void setor_tunai(int str){
         this.saldo = str+this.saldo;
            System.out.println("===     SETOR TUNAI     ===");
            System.out.println("Nilai setor tunai : " + str);
            System.out.println("Saldo Saat Ini    : "+this.saldo);
            System.out.println("");
        }
}
