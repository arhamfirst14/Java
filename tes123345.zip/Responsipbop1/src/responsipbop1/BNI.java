package responsipbop1;

class BNI extends ATM {
    protected String username, pin;
    
    BNI(){
        this.username="Yanto";
        this.pin="123456";
    }
    
    public void setUsername(String user){this.username=user;}
    public void setPin(String pinn){this.pin=pinn;}
    public String getUsername(){return this.username;}
    public String getPin(){return this.pin;}

    @Override
    public void lihat_saldo(int sld) {
        super.lihat_saldo(sld); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void tarik_tunai(int trk) {
        super.tarik_tunai(trk); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setor_tunai(int str) {
        super.setor_tunai(str); //To change body of generated methods, choose Tools | Templates.
    }  
    
    public void LoginUser(){
                System.out.println("Masukkan Username : ");
                String user=scn.nextLine();
                System.out.println("Masukkan Pin      : ");
                String pinn=scn.nextLine();
//                System.out.println("Konfirmasi password : ");
//                String iKonPass=scn2.nextLine();
                System.out.println();
                if(user.equals(this.username) && pinn.equals(this.pin)){
                    System.out.println("Berhasil Login");                  
                    this.username=user;
                    this.pin=pinn;
                }else{
                    System.out.println("Gagal Login");
//                    System.exit(0);
                }
    }
    
    
}
